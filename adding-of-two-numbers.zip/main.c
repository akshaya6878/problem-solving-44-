#include<stdio.h>
int main()
{
    int a,b,c;
    printf("enter the value of a");
    scanf("%d",&a);
    printf("enter te value o b");
    scanf("%d",&b);
    //adding of two numbers
    c=a+b;
    printf("the value of c is %d",c);
    return 0;
}