#include<stdio.h>
#include<math.h>
int main()
{
int f;
printf("enter the value of f");
scanf("%d",&f);
//changing the temperature from faranheat to celsius
float c=(f-32)/18;
printf("celsius=%f",c);
    return 0;
}
