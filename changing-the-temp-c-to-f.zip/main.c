#include<stdio.h>
#include<math.h>
int main()
{
int c;
printf("enter the value of c");
scanf("%d",&c);
//changing the temperature from celsius to faranheat
float f=(1.8*c)+32;
printf("faranheat=%f",f);
    return 0;
}
