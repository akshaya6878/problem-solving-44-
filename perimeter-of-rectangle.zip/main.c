#include<stdio.h>
int main()
{
    int l,b,a;
    printf("enter the length of rectangle");
    scanf("%d",&l);
    printf("enter the breadth of rectangle");
    scanf("%d",&b);
    //perimeter of rectangle
    a=l*b;
    printf("the value of a is %d",a);
    return 0;
}
