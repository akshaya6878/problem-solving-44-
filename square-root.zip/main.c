#include<stdio.h>
#include<math.h>
int main()
{
    int n,r;
    printf("enter the number");
    scanf("%d",&n);
    r=sqrt(n);
    printf("root is %d",r);
    return 0;
}